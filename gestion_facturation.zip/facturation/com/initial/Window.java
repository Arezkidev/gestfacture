package com.initial;

import javax.swing.*;

/**
 * Created by Lulu on 26/04/2016.
 */

public class Window extends JFrame {
    public Window(){
        this.setTitle("CROSL Facturation");
        this.setSize(700,400);
        JMenuBar menu = new JMenuBar();

        JMenu ligue = new JMenu("Ligue");
        JMenuItem ajouterL = new JMenuItem("Ajouter"); /*Appeler l'objet ici*/
        JMenuItem consulterL = new JMenuItem("Consulter");
        ligue.add(ajouterL);
        ligue.add(consulterL);

        JMenu facture = new JMenu("Facture");
        JMenuItem ajouterF = new JMenuItem("Ajouter"); /*Appeler l'objet ici*/
        JMenuItem consulterF = new JMenuItem("Consulter");
        facture.add(ajouterF);
        facture.add(consulterF);

        JMenu prestation = new JMenu("Prestation");
        JMenuItem ajouterP = new JMenuItem("Ajouter"); /*Appeler l'objet ici*/
        JMenuItem consulterP = new JMenuItem("Consulter");
        prestation.add(ajouterP);
        prestation.add(consulterP);

        JMenu tresorier = new JMenu("Tresorier");
        JMenuItem ajouterT = new JMenuItem("Ajouter"); /*Appeler l'objet ici*/
        JMenuItem consulterT = new JMenuItem("Consulter");
        tresorier.add(ajouterT);
        tresorier.add(consulterT);

        menu.add(ligue);
        menu.add(facture);
        menu.add(prestation);
        menu.add(tresorier);

        setJMenuBar(menu);

        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
