package com.initial;

/**
 * Created by Ludwig Roger on 23/04/2016.
 */

public class Main {
    public static void main(String[] args){
        /*Tresorier unTresorier = new Tresorier("Mr","Roger","Ludwig","26 Rue Poussin",75016,"Paris","roger.ludwig@ymail.com","0602525787",true);
        Ligue ligue1 = new Ligue("FC Lorraine",12890,"Football",true);
        Ligue ligue2 = new Ligue("Ligue Escrime",12897,"Escrime",true);
        Ligue ligue3 = new Ligue("Bascket Club",12896,"Bascket",true);

        unTresorier.addToListeLigues(ligue1);
        unTresorier.addToListeLigues(ligue2);
        unTresorier.addToListeLigues(ligue3);

        System.out.println(unTresorier);
        System.out.println(unTresorier.getListeLigues());
        System.out.println(unTresorier.getAdresse());*/

        Window fenetre = new Window();
        fenetre.setVisible(true);

    }
}
