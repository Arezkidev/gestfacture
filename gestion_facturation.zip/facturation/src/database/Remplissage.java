/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.*;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import static com.itextpdf.text.pdf.PdfName.USER;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import static java.util.jar.Pack200.Packer.PASS;
import javax.swing.table.DefaultTableModel;


public class Remplissage {

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://51.254.220.183/facturation";

    // Database credentials
    private static final String USER = "facturation";
    private static final String PASS = "2Jhw7tNP3Xn4xVhz";
    
    
public static DefaultTableModel tabligues() throws SQLException{
    Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
        Statement stmt = conn.createStatement();
         DefaultTableModel TM;
        TM = new DefaultTableModel();
        try{
            // STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");
            String sql;
            sql = "SELECT * FROM ligues";
            ResultSet rs = stmt.executeQuery(sql);
            //Création du tableau
            TM = new DefaultTableModel();
            TM.addColumn("Numéro de la ligue");
            TM.addColumn("Nom de la ligue");
            TM.addColumn("Nom du trésorier");
            TM.addColumn("Email du trésorier");
            TM.addColumn("Sport");
            
         while(rs.next())
            {
                Object[] ligne = {rs.getString("numero"),rs.getString("nom"),rs.getString("tresorier"),rs.getString("email_tresorier"),rs.getString("sport")};
                TM.addRow(ligne);
            }
        }
        catch(SQLException | ClassNotFoundException e){
            e.printStackTrace();
        }
        return TM;
    }


public static DefaultTableModel tabfacture() throws SQLException{
    Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
        Statement stmt = conn.createStatement();
         DefaultTableModel TM;
        TM = new DefaultTableModel();
        try{
            // STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");
            String sql;
            sql = "SELECT * FROM factures";
            ResultSet rs = stmt.executeQuery(sql);
            //Création du tableau
            TM = new DefaultTableModel();
            TM.addColumn("Numéro de la facture");
            TM.addColumn("Client");
            TM.addColumn("Date de la facture");

            
         while(rs.next())
            {
                Object[] ligne = {rs.getString("numero"),rs.getString("client"),rs.getString("date")};
                TM.addRow(ligne);
            }
        }
        catch(SQLException | ClassNotFoundException e){
            e.printStackTrace();
        }
        return TM;
    }

public static DefaultTableModel tabpresta() throws SQLException{
    Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
        Statement stmt = conn.createStatement();
         DefaultTableModel TM;
        TM = new DefaultTableModel();
        try{
            // STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");
            String sql;
            sql = "SELECT * FROM prestations";
            ResultSet rs = stmt.executeQuery(sql);
            //Création du tableau
            TM = new DefaultTableModel();
            TM.addColumn("reference de la prestation");
            TM.addColumn("description de la prestation");
            TM.addColumn("prix unitaire");

            
         while(rs.next())
            {
                Object[] ligne = {rs.getString("reference"),rs.getString("description"),rs.getString("prix")};
                TM.addRow(ligne);
            }
        }
        catch(SQLException | ClassNotFoundException e){
            e.printStackTrace();
        }
        return TM;
    }
    
}
